"""
categorizer.py — Módulo de Categorização Inteligente
Classifica descrições de transações bancárias usando a API da Anthropic.

Estratégia em duas camadas:
  1. Regras estáticas (rápido, sem custo de API) — cobre ~70% dos casos
  2. IA (Anthropic Claude) para os casos ambíguos restantes
"""

import os
import json
import anthropic
from typing import Optional

# --- Mapeamento estático de palavras-chave para categorias ---
# Processa primeiro para reduzir chamadas à API
STATIC_RULES: dict[str, list[str]] = {
    "Transporte": [
        "uber", "99", "cabify", "lyft", "metro", "metrô", "onibus", "ônibus",
        "bilhete", "bom", "estacionamento", "shell", "posto", "combustivel",
        "gasolina", "pedagio", "pedágio", "sem parar", "autopass", "move",
    ],
    "Alimentação": [
        "ifood", "rappi", "uber eats", "mcdonalds", "mcdonald", "burger king",
        "subway", "pizzaria", "lanchonete", "restaurante", "padaria", "mercado",
        "supermercado", "hortifruti", "açougue", "atacadão", "carrefour",
        "extra", "pão de açúcar", "sams club", "costco",
    ],
    "Saúde": [
        "farmacia", "farmácia", "drogasil", "ultrafarma", "droga raia",
        "hospital", "clinica", "clínica", "médico", "dentista", "plano de saúde",
        "unimed", "amil", "bradesco saude", "hapvida", "lab", "exame",
    ],
    "Lazer & Entretenimento": [
        "netflix", "spotify", "amazon prime", "disney", "hbo", "globoplay",
        "deezer", "youtube premium", "apple tv", "cinemark", "uci cinema",
        "teatro", "show", "ingresso", "steam", "playstation", "xbox",
    ],
    "Educação": [
        "udemy", "coursera", "alura", "fiap", "faculdade", "universidade",
        "livros", "amazon kindle", "material escolar", "curso",
    ],
    "Moradia": [
        "condominio", "condomínio", "aluguel", "iptu", "luz", "água",
        "cemig", "sabesp", "copel", "enel", "energia", "gás", "comgas",
        "internet", "claro", "tim", "vivo", "oi",
    ],
    "Compras Online": [
        "amazon", "mercado livre", "shopee", "americanas", "magalu",
        "magazine luiza", "submarino", "casas bahia", "aliexpress",
    ],
    "Bancos & Finanças": [
        "ted", "pix", "transferencia", "transferência", "saldo", "rendimento",
        "juros", "tarifa", "anuidade", "iof", "imposto", "seguro",
    ],
    "Vestuário": [
        "zara", "renner", "c&a", "riachuelo", "hm", "h&m", "nike", "adidas",
        "reserva", "farm", "arezzo", "centauro",
    ],
}

# Instancia o cliente da Anthropic (usa variável de ambiente ANTHROPIC_API_KEY)
client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY", ""))

ALL_CATEGORIES = list(STATIC_RULES.keys()) + ["Outros"]


def categorize_transactions(transactions: list[dict]) -> list[dict]:
    """
    Categoriza todas as transações.
    Aplica regras estáticas primeiro; envia apenas os casos não resolvidos para a IA.
    """
    uncategorized = []

    for tx in transactions:
        category = _apply_static_rules(tx["description"])
        if category:
            tx["category"] = category
        else:
            uncategorized.append(tx)

    # Envia os não categorizados em batch para a IA (mais eficiente e barato)
    if uncategorized:
        _categorize_with_ai(uncategorized)

    # Garante que todos tenham categoria
    for tx in transactions:
        if not tx.get("category"):
            tx["category"] = "Outros"

    return transactions


def _apply_static_rules(description: str) -> Optional[str]:
    """Verifica se a descrição corresponde a alguma regra estática."""
    desc_lower = description.lower()
    for category, keywords in STATIC_RULES.items():
        if any(kw in desc_lower for kw in keywords):
            return category
    return None


def _categorize_with_ai(transactions: list[dict]) -> None:
    """
    Envia as descrições não categorizadas para Claude classificar em batch.
    Modifica a lista in-place adicionando o campo 'category'.
    
    Sub-prompt de categorização interno — engenheirado para resposta JSON pura.
    """
    if not transactions:
        return

    descriptions = [
        {"index": i, "description": tx["description"], "amount": tx["amount"]}
        for i, tx in enumerate(transactions)
    ]

    categories_str = ", ".join(ALL_CATEGORIES)

    # Sub-prompt interno de categorização
    system_prompt = f"""Você é um classificador financeiro preciso.
Recebe uma lista JSON de transações bancárias e retorna APENAS um JSON com as categorias.
Categorias disponíveis: {categories_str}
Regras:
- Use "Outros" somente quando nenhuma outra categoria se encaixar
- Considere o valor: valores altos negativos em "Banco & Finanças" podem ser transferências
- Retorne SOMENTE JSON válido no formato: [{{"index": 0, "category": "Alimentação"}}, ...]
- Sem texto explicativo, sem markdown, apenas JSON puro"""

    user_message = f"Classifique estas transações:\n{json.dumps(descriptions, ensure_ascii=False)}"

    try:
        response = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=1024,
            system=system_prompt,
            messages=[{"role": "user", "content": user_message}],
        )

        raw_text = response.content[0].text.strip()
        # Remove markdown fences se presentes (defensive parsing)
        raw_text = raw_text.replace("```json", "").replace("```", "").strip()

        results = json.loads(raw_text)

        # Aplica as categorias retornadas
        result_map = {item["index"]: item["category"] for item in results}
        for i, tx in enumerate(transactions):
            tx["category"] = result_map.get(i, "Outros")

    except (json.JSONDecodeError, KeyError, anthropic.APIError) as e:
        # Fallback gracioso: marca tudo como "Outros" se a IA falhar
        print(f"[categorizer] Erro na categorização por IA: {e}")
        for tx in transactions:
            tx["category"] = "Outros"
