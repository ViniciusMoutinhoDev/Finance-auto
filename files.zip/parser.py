"""
parser.py — Motor de Extração de PDF (coração do sistema)
Responsável por transformar um PDF bancário em uma lista padronizada de transações.

Estratégia multi-etapa:
  1. Tentar extração estruturada via pdfplumber (tabelas detectadas automaticamente)
  2. Fallback para extração por regex linha a linha (para PDFs sem tabelas)
  3. Normalização final para o schema padrão

SCHEMA DE TRANSAÇÃO:
{
  "date": "YYYY-MM-DD",
  "description": "string",
  "amount": float,       # negativo = débito, positivo = crédito
  "type": "debit" | "credit",
  "category": null       # preenchido pelo categorizer
}
"""

import re
import pdfplumber
from datetime import datetime
from typing import Optional
import io


# --- Padrões Regex para diferentes layouts bancários ---

# Padrão 1: DD/MM/YYYY  Descrição  R$ 1.234,56
PATTERN_BR_STANDARD = re.compile(
    r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([-+]?\s*R?\$?\s*[\d.]+,\d{2})",
    re.IGNORECASE,
)

# Padrão 2: DD/MM  Descrição  1.234,56 (sem ano, sem R$)
PATTERN_BR_SHORT = re.compile(
    r"(\d{2}/\d{2})\s+(.+?)\s+([-+]?\s*[\d.]+,\d{2})\s*$",
    re.MULTILINE,
)

# Padrão 3: MM/DD/YYYY  Descrição  1,234.56 (formato americano — fintechs internacionais)
PATTERN_US_FORMAT = re.compile(
    r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([-+]?\s*[\d,]+\.\d{2})",
    re.IGNORECASE,
)


def extract_transactions(pdf_bytes: bytes) -> list[dict]:
    """
    Pipeline principal de extração.
    Tenta múltiplas estratégias e retorna a que produzir mais transações.
    """
    results = []

    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        all_text = ""
        all_tables = []

        for page in pdf.pages:
            # Estratégia A: extração via tabelas (mais precisa quando disponível)
            tables = page.extract_tables()
            if tables:
                all_tables.extend(tables)

            # Coleta texto bruto para fallback
            text = page.extract_text()
            if text:
                all_text += text + "\n"

    # Tenta tabelas primeiro
    if all_tables:
        table_results = _parse_from_tables(all_tables)
        if len(table_results) > 0:
            results = table_results

    # Se tabelas não produziram resultado suficiente, usa regex no texto
    if len(results) < 3 and all_text:
        regex_results = _parse_from_text(all_text)
        if len(regex_results) > len(results):
            results = regex_results

    return results


def _parse_from_tables(tables: list) -> list[dict]:
    """
    Extrai transações de tabelas detectadas pelo pdfplumber.
    Identifica automaticamente colunas de data, descrição e valor.
    """
    transactions = []

    for table in tables:
        if not table or len(table) < 2:
            continue

        # Tenta identificar colunas pelo cabeçalho
        header = [str(cell).lower().strip() if cell else "" for cell in table[0]]
        date_col = _find_column(header, ["data", "date", "dt", "vencimento"])
        desc_col = _find_column(header, ["descrição", "descricao", "historico", "lançamento", "merchant", "estabelecimento"])
        value_col = _find_column(header, ["valor", "value", "amount", "débito", "crédito", "montante"])

        # Se não encontrou pelo cabeçalho, tenta inferir pela estrutura
        if date_col is None or value_col is None:
            date_col, desc_col, value_col = _infer_columns(table)

        if date_col is None or value_col is None:
            continue

        for row in table[1:]:
            if not row or len(row) <= max(date_col or 0, value_col):
                continue

            raw_date = str(row[date_col]).strip() if date_col is not None else ""
            raw_desc = str(row[desc_col]).strip() if desc_col is not None else "Sem descrição"
            raw_value = str(row[value_col]).strip() if row[value_col] else ""

            parsed_date = _parse_date(raw_date)
            parsed_amount = _parse_amount(raw_value)

            if not parsed_date or parsed_amount is None:
                continue

            transactions.append({
                "date": parsed_date,
                "description": raw_desc,
                "amount": parsed_amount,
                "type": "credit" if parsed_amount > 0 else "debit",
                "category": None,
            })

    return transactions


def _parse_from_text(text: str) -> list[dict]:
    """
    Extrai transações usando regex no texto bruto.
    Fallback para PDFs sem estrutura de tabela (ex: Bradesco, Santander antigo).
    """
    transactions = []
    current_year = datetime.now().year

    for pattern, date_fmt, amount_fmt in [
        (PATTERN_BR_STANDARD, "full_br", "br"),
        (PATTERN_BR_SHORT, "short_br", "br"),
        (PATTERN_US_FORMAT, "full_us", "us"),
    ]:
        matches = pattern.findall(text)
        if not matches:
            continue

        for raw_date, raw_desc, raw_value in matches:
            parsed_date = _parse_date(raw_date.strip(), date_fmt, current_year)
            parsed_amount = _parse_amount(raw_value.strip(), amount_fmt)

            if not parsed_date or parsed_amount is None:
                continue

            transactions.append({
                "date": parsed_date,
                "description": raw_desc.strip(),
                "amount": parsed_amount,
                "type": "credit" if parsed_amount > 0 else "debit",
                "category": None,
            })

        if transactions:
            break  # Usa o primeiro padrão que funcionar

    return transactions


# --- Helpers ---

def _find_column(header: list, keywords: list) -> Optional[int]:
    for i, cell in enumerate(header):
        for kw in keywords:
            if kw in cell:
                return i
    return None


def _infer_columns(table: list) -> tuple:
    """Infere colunas olhando os dados (heurística por padrão de conteúdo)."""
    if len(table) < 2:
        return None, None, None

    date_col = value_col = desc_col = None
    sample_row = next((r for r in table[1:] if r and any(r)), None)
    if not sample_row:
        return None, None, None

    for i, cell in enumerate(sample_row):
        cell_str = str(cell or "").strip()
        if re.match(r"\d{2}/\d{2}", cell_str) and date_col is None:
            date_col = i
        elif re.search(r"[\d.]+,\d{2}", cell_str) and value_col is None:
            value_col = i

    # Assume que a coluna do meio (entre data e valor) é descrição
    if date_col is not None and value_col is not None:
        middle = [i for i in range(len(sample_row)) if i not in (date_col, value_col)]
        desc_col = middle[0] if middle else None

    return date_col, desc_col, value_col


def _parse_date(raw: str, fmt_hint: str = "auto", fallback_year: int = 2024) -> Optional[str]:
    """Converte string de data para YYYY-MM-DD."""
    raw = raw.strip().replace(" ", "")
    formats_to_try = [
        ("%d/%m/%Y", r"\d{2}/\d{2}/\d{4}"),
        ("%d/%m/%y", r"\d{2}/\d{2}/\d{2}"),
        ("%m/%d/%Y", r"\d{2}/\d{2}/\d{4}"),
        ("%d-%m-%Y", r"\d{2}-\d{2}-\d{4}"),
        ("%Y-%m-%d", r"\d{4}-\d{2}-\d{2}"),
    ]

    for fmt, _ in formats_to_try:
        try:
            return datetime.strptime(raw, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue

    # Padrão curto DD/MM sem ano
    m = re.match(r"(\d{2})/(\d{2})$", raw)
    if m:
        try:
            return datetime.strptime(f"{m.group(1)}/{m.group(2)}/{fallback_year}", "%d/%m/%Y").strftime("%Y-%m-%d")
        except ValueError:
            pass

    return None


def _parse_amount(raw: str, fmt: str = "br") -> Optional[float]:
    """
    Converte string de valor para float.
    Suporta formato BR (1.234,56) e US (1,234.56).
    Preserva sinal negativo para débitos.
    """
    raw = re.sub(r"R?\$\s*", "", raw).strip()
    is_negative = raw.startswith("-") or raw.endswith("-") or "()" in raw or raw.startswith("(")
    raw = re.sub(r"[()+-]", "", raw).strip()

    try:
        if fmt == "us":
            amount = float(raw.replace(",", ""))
        else:  # br (default)
            amount = float(raw.replace(".", "").replace(",", "."))

        return -abs(amount) if is_negative else amount
    except (ValueError, AttributeError):
        return None
